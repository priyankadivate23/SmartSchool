package com.smartschool.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartSchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
