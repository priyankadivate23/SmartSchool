package com.smartschool;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SchoolController 
{
	@GetMapping("/get")
	public String Home()
	{
		return "form";
	}
}
